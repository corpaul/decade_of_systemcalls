This document contains the description of the data files and sample queries which were used for the analysis in the paper "Analyzing a Decade of Linux System Calls".

Note that all commit IDs in the data refer to commits in the Linux GitHub repository (https://github.com/torvalds/linux).

The data of our manual analysis:
- systemcallList.csv: The list of Linux system calls along with their assigned categories:
	-- name			--> The name of the system call.
	-- category		--> The category of the system call.

- finalData.csv: The final results of the manual study. Most of the analysis of the paper is based on this file. This file includes the following fields:
	-- commitNo		--> The commit ID.
	-- date			--> The date of the commit.
	-- fixFilesCount	--> The number of files that were changed by the commit.
	-- fixSizeAdd		--> The number of lines of code that were added by the commit.
	-- fixSizeDel		--> The number of lines of code that were removed by the commit.
	-- fixDescLine		--> The number of lines in the commit message.
	-- fixDescSize		--> The number of words in the commit message.
	-- syscallName		--> The system calls that were changed by the commit.
	-- category		--> The categories of the system calls that were changed by the commit.
	-- author		--> The author/developer of the commit.
	-- restructuring	--> A boolean that shows whether the commit is classified as a restructuring change.
	-- bug			--> A boolean that shows whether the commit is classified as a bug fix change.
	-- addRemove		--> A boolean that shows whether the commit is classified as an addRemove change.
	-- improvement		--> A boolean that shows whether the commit is classified as an improvement change.
	-- semanticBug		--> A boolean that shows whether a bug fix is classified as a semantic bug.
	-- memoryBug		--> A boolean that shows whether a bug fix is classified as a memory bug.
	-- concurrencyBug	--> A boolean that shows whether a bug fix is classified as a concurrency bug.
	-- compatibilityBug	--> A boolean that shows whether a bug fix is classified as a compatibility bug.
	-- errorCodeBug		--> A boolean that shows whether a bug fix is classified as an error code bug.

- finalData_split.csv: Contains the same data as finalData.csv, however, if a commit changed multiple system calls, then we copied the commit for each of the system calls. This data set was used when our analysis was focused on the system calls (e.g., to calculate entropy), rather than the commits. For example, if commit C1 changes system call A and B, the commit in finalData.csv is shown as "C1,A;B", while in finalData_split.csv there are two records: "C1,A" and "C1,B".


Intermediate steps in the data extraction:
- potentialChanges.csv: The list of 88,178 Linux commits of which the commit message contains one of the keywords that are mentioned in the paper.
	-- commitNo	--> The commit ID.

- fileBasedFilter.csv: The list of 12,329 commits, which were kept after applying the heuristics based on the files that are changed by a commit.
	-- commitNo	--> The commit ID.


Other data that we used in our paper:
- allLinuxCommits.csv: The list of all Linux commits that were extracted from the Linux repository (https://github.com/torvalds/linux). This file contains the following fields:
	-- commitNo	--> The Commit ID.
	-- cnt		--> The number of files that were changed by the commit.
	-- added	--> The number of lines of code that were added by the commit.
	-- removed	--> The number of lines of code that were removed by the commit.
	-- purechange	--> The number of lines of code that the codebase grew by this commit (added - removed).


- entropyFinalData: The list of system calls along with their entropy and category.
	-- name		--> The name of the system call.
	-- category	--> The category of the system call.
	-- entropy	--> The entropy of the system call.


----------------------------------- Useful queries -----------------------------------------------------------------------

After importing finalData.csv and finalData_split.csv into the database 'syscalls' in a typical database server such as MySQL, the following sql queries can be helpful to analyze the data:

-- Count the number of changes based on the classification (restructuring, bug, addRemove, and improvment)
	SELECT    
		SUM(CASE WHEN restructuring = 'true' THEN 1 ELSE 0 END) as restructuring, 
		SUM(CASE WHEN bug = 'true' THEN 1 ELSE 0 END) as bug,
		SUM(CASE WHEN improvment = 'true' THEN 1 ELSE 0 END) as improvement,
		SUM(CASE WHEN addremove = 'true' THEN 1 ELSE 0 END) as addremove
	FROM syscalls.finalData

-- Trend of the changes over the year based on the classification
	SELECT 
		TRIM(substr(`date`,20,5)) as year, count(*) as allchange,  
		SUM(CASE WHEN restructuring = 'true' THEN 1 ELSE 0 END) as restructuring, 
		SUM(CASE WHEN bug = 'true' THEN 1 ELSE 0 END) as bug,
		SUM(CASE WHEN improvment = 'true' THEN 1 ELSE 0 END) as improvement,
		SUM(CASE WHEN addremove = 'true' THEN 1 ELSE 0 END) as addremove
	FROM syscalls.finalData
	GROUP BY TRIM(substr(`date`,20,5))


-- Count the number of bug fixes based on the bug classification 
	SELECT 
		SUM(CASE WHEN compatibilityBug = 'true' THEN 1 ELSE 0 END) as compatibilityBug, 
		SUM(CASE WHEN memorybug = 'true' THEN 1 ELSE 0 END) as memorybug,
		SUM(CASE WHEN concurrencyBug = 'true' THEN 1 ELSE 0 END) as concurrencyBug,
		SUM(CASE WHEN semanticbug = 'true' THEN 1 ELSE 0 END) as semanticbug,  
		SUM(CASE WHEN errorcodebug = 'true' THEN 1 ELSE 0 END) as errorcodebug
	FROM syscalls.finalData_split
	WHERE bug='true'

-- Count the number of bug fixes based on the bug classification per category
	SELECT category,
		SUM(CASE WHEN compatibilityBug = 'true' THEN 1 ELSE 0 END) as compatibilityBug, 
		SUM(CASE WHEN memorybug = 'true' THEN 1 ELSE 0 END) as memorybug,
		SUM(CASE WHEN concurrencyBug = 'true' THEN 1 ELSE 0 END) as concurrencyBug,
		SUM(CASE WHEN semanticbug = 'true' THEN 1 ELSE 0 END) as semanticbug, 
		SUM(CASE WHEN errorcodebug = 'true' THEN 1 ELSE 0 END) as errorcodebug 
	FROM syscalls.finalData_split
	WHERE bug='true'
	GROUP BY category

-- Find the system calls with the most changes (using finalData_split)
	SELECT
		syscallname, count(*) as allchange,  
		SUM(CASE WHEN restructuring = 'true' THEN 1 ELSE 0 END) as restructuring, 
		SUM(CASE WHEN bug = 'true' THEN 1 ELSE 0 END) as bug,
		SUM(CASE WHEN improvment = 'true' THEN 1 ELSE 0 END) as improvement,
		SUM(CASE WHEN addremove = 'true' THEN 1 ELSE 0 END) as addremove
	FROM syscalls.finalData_split
	GROUP BY syscallname
	ORDER BY allchange DESC

-- Steps to calculate entropy of system calls (using finalData_split)

	-- Calculate the number of bugs per system call and save them in a view   
        CREATE VIEW syscalls.bugCountsPerSyscall as (
		SELECT 
			syscallname, category, count(*) as BugCount 
		FROM syscalls.finalData_split
		WHERE bug='true'
		GROUP BY syscallname,category
	)

	-- Calculate the number of bugs of system calls per year and save them in a view  
	CREATE VIEW syscalls.bugCountsPerSyscallPerYear as (
		SELECT 
			syscallname, TRIM(substr(`date`,20,5)) as `year`, count(*) as BugCount 
		FROM syscalls.finalData_split
		WHERE bug='true'
		GROUP BY syscallname, `year`
		)
  
	-- Calculate the entropy data of  each system call per year and save them in a view
	CREATE VIEW syscalls.entropyData as (
		SELECT
			a.syscallname, a.category, a.bugCount as allBugs, b.bugCount as yearBug, b.bugCount/a.bugCount, 
			log(10,(b.bugCount/a.bugCount)), abs(log(10,(b.bugCount/a.bugCount))* (b.bugCount/a.bugCount)) as entropyOfYear, 
			`year` 
		FROM syscalls.bugCountsPerSyscall as a, syscalls.bugCountsPerSyscallPerYear as b
		WHERE a.syscallname=b.syscallname
	)

	-- Finally, calculate the entropy of each system call   
    	SELECT 
		sysCallName, category, sum(entropyOfYear) as entropy 
	FROM syscalls.entropyData
	GROUP BY sysCallName,category
	ORDER BY category








